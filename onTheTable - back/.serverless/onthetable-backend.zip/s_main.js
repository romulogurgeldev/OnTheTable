
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'felipehenriquee',
  applicationName: 'onthetable-backend',
  appUid: 'rB3N6jTBRdHF6NkzxZ',
  orgUid: '5f61dbed-765a-4926-85e0-7b5d0c745792',
  deploymentUid: 'f689d64c-ec3c-4906-816e-b3d421a3fa31',
  serviceName: 'onthetable-backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'onthetable-backend-dev-main', timeout: 6 };

try {
  const userHandler = require('./dist/serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}