export class ClientUser {}
