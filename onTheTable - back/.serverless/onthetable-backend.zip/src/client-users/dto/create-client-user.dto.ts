export class CreateClientUserDto {
    
}
