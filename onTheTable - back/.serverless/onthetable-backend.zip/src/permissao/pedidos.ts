export class Pedidos {
    permissao: boolean;
    mesas: boolean;
    cozinha: boolean;

}