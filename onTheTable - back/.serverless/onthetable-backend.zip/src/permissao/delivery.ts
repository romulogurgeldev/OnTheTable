export class Delivery {

    permissao: boolean;
    delivery: boolean;


}