export class Ajuste {
    permissao: boolean;
    mesa: boolean;
    cardapio: boolean;
    config: boolean;
    promotion: boolean;

}