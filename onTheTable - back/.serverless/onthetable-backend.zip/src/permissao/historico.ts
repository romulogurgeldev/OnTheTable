export class Historico {

    permissao: boolean;
    historico: boolean;


}