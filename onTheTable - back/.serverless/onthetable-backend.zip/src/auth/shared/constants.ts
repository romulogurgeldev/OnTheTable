export const jwtConstants = {
    secret: '8324hfehfwelksdfks'
}