export class CreatePlanoDto {}
