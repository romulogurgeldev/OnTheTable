export class Plano {}
