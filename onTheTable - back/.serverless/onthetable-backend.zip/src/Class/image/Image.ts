export class Image {
    nome: string;
    key: string;
    location: string;
    
}